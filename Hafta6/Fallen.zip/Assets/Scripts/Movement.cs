using UnityEngine;

public class Movement : MonoBehaviour
{
    public Rigidbody2D rb2D;
    public float hareketHizi;


    private void Update()
    {
        /* Klavyeden sa� ok tu�una veya d tu�una t�kland���nda
           0 ile 1 aras�nda artan bir de�er �retir.
           
            Klavyeden sol ok tu�una veya a tu�una t�kland���nda
            0 ile -1 aras�nda azalan bir de�er �retir.
         */
        float deger = Input.GetAxis("Horizontal");
        rb2D.velocity = new Vector2(deger * hareketHizi * Time.deltaTime, rb2D.velocity.y);
        
        print(deger);
    }
}
