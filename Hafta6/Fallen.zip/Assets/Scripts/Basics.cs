using UnityEngine;
public class Basics : MonoBehaviour
{
    private void Awake(){
        Debug.Log("Awake() �al��t�"); // print("Awake �al��t�");
    }

    private void Start(){
        Debug.Log("Start() �al��t�");
    }

    private void Update(){
        Debug.Log("Update() �al��t�");
    }

    private void FixedUpdate(){
        Debug.Log("FixedUpdate() �al��t�");
    }

    private void LateUpdate(){
        Debug.Log("LateUpdate() �al��t�");
    }
}
